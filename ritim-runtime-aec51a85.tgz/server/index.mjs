import { createServer } from "node:http";
import { createHash, randomBytes, randomUUID } from "node:crypto";
import { existsSync, mkdirSync, readFileSync } from "node:fs";
import { extname, join, normalize, relative, resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";
import { DatabaseSync } from "node:sqlite";

const root = resolve(fileURLToPath(new URL("..", import.meta.url)));
const port = Number(process.env.PORT || 8787);
const host = process.env.HOST || "0.0.0.0";
const dataRoot = resolve(process.env.RITIM_DATA_DIR || join(root, "data"));
mkdirSync(dataRoot, { recursive: true });
const dbPath = resolve(process.env.RITIM_DB_PATH || join(dataRoot, "ritim-kasifleri.sqlite"));
const db = new DatabaseSync(dbPath);
db.exec("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;");

db.exec([
  "CREATE TABLE IF NOT EXISTS players (",
  "  id TEXT PRIMARY KEY,",
  "  token_hash TEXT NOT NULL UNIQUE,",
  "  public_name TEXT NOT NULL,",
  "  avatar_id TEXT NOT NULL,",
  "  total_score INTEGER NOT NULL DEFAULT 0,",
  "  stars INTEGER NOT NULL DEFAULT 0,",
  "  badge_count INTEGER NOT NULL DEFAULT 0,",
  "  best_streak INTEGER NOT NULL DEFAULT 0,",
  "  completed_sessions INTEGER NOT NULL DEFAULT 0,",
  "  endless_runs INTEGER NOT NULL DEFAULT 0,",
  "  created_at TEXT NOT NULL,",
  "  last_seen_at TEXT NOT NULL",
  ");",
  "CREATE TABLE IF NOT EXISTS weekly_scores (",
  "  player_id TEXT NOT NULL,",
  "  week_key TEXT NOT NULL,",
  "  score INTEGER NOT NULL DEFAULT 0,",
  "  correct_count INTEGER NOT NULL DEFAULT 0,",
  "  answer_count INTEGER NOT NULL DEFAULT 0,",
  "  PRIMARY KEY (player_id, week_key),",
  "  FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE",
  ");",
  "CREATE TABLE IF NOT EXISTS sessions (",
  "  player_id TEXT NOT NULL,",
  "  session_id TEXT NOT NULL,",
  "  kind TEXT NOT NULL,",
  "  chapter_id TEXT,",
  "  correct_count INTEGER NOT NULL,",
  "  answer_count INTEGER NOT NULL,",
  "  score INTEGER NOT NULL,",
  "  created_at TEXT NOT NULL,",
  "  PRIMARY KEY (player_id, session_id),",
  "  FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE",
  ");",
  "CREATE TABLE IF NOT EXISTS badges (",
  "  player_id TEXT NOT NULL,",
  "  badge_id TEXT NOT NULL,",
  "  earned_at TEXT NOT NULL,",
  "  PRIMARY KEY (player_id, badge_id),",
  "  FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE",
  ");",
  "CREATE TABLE IF NOT EXISTS activity (",
  "  id INTEGER PRIMARY KEY AUTOINCREMENT,",
  "  player_id TEXT NOT NULL,",
  "  event_type TEXT NOT NULL,",
  "  message TEXT NOT NULL,",
  "  created_at TEXT NOT NULL,",
  "  FOREIGN KEY (player_id) REFERENCES players(id) ON DELETE CASCADE",
  ");",
].join("\n"));

const allowedAvatars = new Set([
  "fox", "owl", "panda", "dolphin", "turtle", "octopus", "tiger", "butterfly",
]);

const chapterLabels = new Map([
  ["memory-camp", "Hafıza Kampı"],
  ["sixes", "Altılar Ormanı"],
  ["sevens", "Yediler Geçidi"],
  ["eights", "Sekizler İstasyonu"],
  ["nines", "Dokuzlar Zirvesi"],
  ["big-hops", "Büyük Sıçramalar"],
  ["backward-tunnel", "Geri Dönüş Tüneli"],
  ["pattern-detective", "Örüntü Dedektifi"],
  ["mastery", "Ustalık Seferi"],
]);

const badgeLabels = new Map([
  ["badge-sixes", "6'lar Ustası"],
  ["badge-sevens", "7'ler Ustası"],
  ["badge-eights", "8'ler Ustası"],
  ["badge-nines", "9'lar Ustası"],
  ["badge-big-hops", "Büyük Sıçramalar"],
  ["badge-backward-tunnel", "Geri Sayım Ustası"],
  ["badge-pattern-detective", "Örüntü Dedektifi"],
  ["badge-mastery", "Ritmik Usta"],
  ["badge-perfect-10", "Hatasız 10"],
  ["badge-streak-25", "Hatasız 25"],
]);

const rate = new Map();
const RATE_WINDOW_MS = 60_000;
const TOKEN_RATE_LIMIT = 240;
const IP_RATE_LIMIT = 600;
let lastRateCleanup = 0;

function nowIso() {
  return new Date().toISOString();
}

function weekKey(date = new Date()) {
  const d = new Date(Date.UTC(date.getUTCFullYear(), date.getUTCMonth(), date.getUTCDate()));
  const day = d.getUTCDay() || 7;
  d.setUTCDate(d.getUTCDate() + 4 - day);
  const yearStart = new Date(Date.UTC(d.getUTCFullYear(), 0, 1));
  const week = Math.ceil((((d - yearStart) / 86400000) + 1) / 7);
  return String(d.getUTCFullYear()) + "-W" + String(week).padStart(2, "0");
}

function tokenHash(token) {
  return createHash("sha256").update(token).digest("hex");
}

function cleanName(value) {
  if (typeof value !== "string") return "";
  const normalized = value
    .normalize("NFC")
    .replace(/[^\p{L}\p{N}'-]/gu, " ")
    .replace(/\s+/g, " ")
    .trim();
  return (normalized.split(" ")[0] || "").slice(0, 18);
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "content-type": "application/json; charset=utf-8",
    "content-length": Buffer.byteLength(body),
    "cache-control": "no-store",
    "x-content-type-options": "nosniff",
    "x-frame-options": "DENY",
    "referrer-policy": "no-referrer",
    "permissions-policy": "camera=(), microphone=(), geolocation=()",
    "content-security-policy":
      "default-src 'self'; img-src 'self' data:; font-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
  });
  res.end(body);
}

function limited(req) {
  const token = req.headers["x-player-token"];
  const hasUsableToken =
    typeof token === "string" && token.length >= 16 && token.length <= 128;
  const key = hasUsableToken
    ? "token:" + tokenHash(token)
    : "ip:" + (req.socket.remoteAddress || "unknown");
  const limit = hasUsableToken ? TOKEN_RATE_LIMIT : IP_RATE_LIMIT;
  const current = Date.now();
  if (current - lastRateCleanup > RATE_WINDOW_MS) {
    for (const [entryKey, entry] of rate) {
      if (current - entry.started > RATE_WINDOW_MS * 2) rate.delete(entryKey);
    }
    lastRateCleanup = current;
  }
  const existing = rate.get(key);
  if (!existing || current - existing.started > RATE_WINDOW_MS) {
    rate.set(key, { started: current, count: 1 });
    return false;
  }
  existing.count += 1;
  return existing.count > limit;
}

async function readJson(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 32768) throw new Error("BODY_TOO_LARGE");
    chunks.push(chunk);
  }
  if (chunks.length === 0) return {};
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8"));
  } catch {
    throw new Error("INVALID_JSON");
  }
}

function playerByToken(token) {
  if (!token || typeof token !== "string" || token.length < 16 || token.length > 128) return null;
  return db.prepare("SELECT * FROM players WHERE token_hash = ?").get(tokenHash(token)) ?? null;
}

function rankRows(sql, params = []) {
  const rows = db.prepare(sql).all(...params);
  return rows.map((row, index) => ({
    rank: index + 1,
    id: row.id,
    name: row.public_name,
    avatar: row.avatar_id,
    score: Number(row.score || 0),
    badges: Number(row.badge_count || 0),
    bestStreak: Number(row.best_streak || 0),
  }));
}

function activityMessage(playerName, eventType, value) {
  if (eventType === "badge") return playerName + ", " + value + " rozetini kazandı.";
  if (eventType === "endless") return playerName + ", Sonsuz Keşif'te yeni bir tur tamamladı.";
  return playerName + ", " + value + " bölümünü tamamladı.";
}

function addActivity(playerId, eventType, value) {
  const player = db.prepare("SELECT public_name FROM players WHERE id = ?").get(playerId);
  if (!player) return;
  db.prepare(
    "INSERT INTO activity(player_id, event_type, message, created_at) VALUES (?, ?, ?, ?)",
  ).run(playerId, eventType, activityMessage(player.public_name, eventType, value), nowIso());
  db.prepare(
    "DELETE FROM activity WHERE id NOT IN (SELECT id FROM activity ORDER BY id DESC LIMIT 250)",
  ).run();
}

function handleRegister(body) {
  const name = cleanName(body.name);
  const avatar = allowedAvatars.has(body.avatar) ? body.avatar : "fox";
  if (!name) return { status: 400, payload: { error: "NAME_REQUIRED" } };
  const token =
    typeof body.deviceToken === "string" && body.deviceToken.length >= 16 && body.deviceToken.length <= 128
      ? body.deviceToken
      : randomBytes(24).toString("base64url");
  const hash = tokenHash(token);
  const existing = db.prepare("SELECT * FROM players WHERE token_hash = ?").get(hash);
  const now = nowIso();
  if (existing) {
    db.prepare(
      "UPDATE players SET public_name = ?, avatar_id = ?, last_seen_at = ? WHERE id = ?",
    ).run(name, avatar, now, existing.id);
    return {
      status: 200,
      payload: { player: { id: existing.id, name, avatar }, deviceToken: token },
    };
  }
  const id = randomUUID();
  db.prepare(
    "INSERT INTO players(id, token_hash, public_name, avatar_id, created_at, last_seen_at) VALUES (?, ?, ?, ?, ?, ?)",
  ).run(id, hash, name, avatar, now, now);
  return {
    status: 201,
    payload: { player: { id, name, avatar }, deviceToken: token },
  };
}

function handleSession(body, token) {
  const player = playerByToken(token);
  if (!player) return { status: 401, payload: { error: "PLAYER_NOT_FOUND" } };

  const sessionId =
    typeof body.sessionId === "string" && /^[a-zA-Z0-9-]{8,80}$/.test(body.sessionId)
      ? body.sessionId
      : "";
  if (!sessionId) return { status: 400, payload: { error: "SESSION_ID_REQUIRED" } };

  const duplicate = db.prepare(
    "SELECT score FROM sessions WHERE player_id = ? AND session_id = ?",
  ).get(player.id, sessionId);
  if (duplicate) {
    return {
      status: 200,
      payload: { points: Number(duplicate.score), newBadges: 0, weekKey: weekKey(), duplicate: true },
    };
  }

  const total = Math.max(1, Math.min(30, Math.trunc(Number(body.total) || 1)));
  const correct = Math.max(0, Math.min(total, Math.trunc(Number(body.correct) || 0)));
  const bestStreak = Math.max(0, Math.min(total, Math.trunc(Number(body.bestStreak) || 0)));
  const hintCount = Math.max(0, Math.min(total, Math.trunc(Number(body.hintCount) || 0)));
  const durationMs = Math.max(1000, Math.min(7_200_000, Math.trunc(Number(body.durationMs) || 1000)));
  const accuracy = correct / total;
  const kind = body.kind === "endless" ? "endless" : "chapter";
  const chapterId =
    kind === "chapter" && chapterLabels.has(body.chapterId) ? body.chapterId : null;
  if (kind === "chapter" && !chapterId) {
    return { status: 400, payload: { error: "CHAPTER_NOT_ALLOWED" } };
  }

  const cutoff = new Date(Date.now() - 86_400_000).toISOString();
  const recentRepeats = Number(
    db.prepare(
      "SELECT COUNT(*) AS count FROM sessions " +
        "WHERE player_id = ? AND kind = ? AND COALESCE(chapter_id, '') = ? AND created_at >= ?",
    ).get(player.id, kind, chapterId || "", cutoff).count,
  );
  const repeatFactor = Math.max(0.45, 1 - Math.min(5, recentRepeats) * 0.1);
  const accuracyPoints = Math.round(accuracy * 110);
  const masteryPoints = correct * 12;
  const streakPoints = Math.min(bestStreak, 25) * 3;
  const completionPoints = accuracy >= 0.7 ? 30 : 10;
  const independentBonus = hintCount === 0 && accuracy >= 0.8 ? 15 : 0;
  const rawPoints =
    accuracyPoints + masteryPoints + streakPoints + completionPoints + independentBonus;
  const points = Math.max(10, Math.round(rawPoints * repeatFactor));
  const stars = correct * 5 + (accuracy >= 0.9 ? 20 : accuracy >= 0.75 ? 10 : 0);
  const wk = weekKey();
  const now = nowIso();
  const newBadgeIds = [];

  db.exec("BEGIN");
  try {
    db.prepare(
      "INSERT INTO sessions(player_id, session_id, kind, chapter_id, correct_count, answer_count, score, created_at) " +
        "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
    ).run(player.id, sessionId, kind, chapterId, correct, total, points, now);

    db.prepare([
      "UPDATE players SET",
      " total_score = total_score + ?,",
      " stars = stars + ?,",
      " best_streak = MAX(best_streak, ?),",
      " completed_sessions = completed_sessions + 1,",
      " endless_runs = endless_runs + ?,",
      " last_seen_at = ?",
      " WHERE id = ?",
    ].join("")).run(points, stars, bestStreak, kind === "endless" ? 1 : 0, now, player.id);

    db.prepare([
      "INSERT INTO weekly_scores(player_id, week_key, score, correct_count, answer_count)",
      " VALUES (?, ?, ?, ?, ?)",
      " ON CONFLICT(player_id, week_key) DO UPDATE SET",
      " score = score + excluded.score,",
      " correct_count = correct_count + excluded.correct_count,",
      " answer_count = answer_count + excluded.answer_count",
    ].join("")).run(player.id, wk, points, correct, total);

    if (chapterId && accuracy >= 0.8) newBadgeIds.push("badge-" + chapterId);
    if (bestStreak >= 10) newBadgeIds.push("badge-perfect-10");
    if (bestStreak >= 25) newBadgeIds.push("badge-streak-25");
    if (kind === "endless") {
      const nextEndlessRuns = Number(player.endless_runs || 0) + 1;
      if (nextEndlessRuns % 3 === 0) {
        newBadgeIds.push("explorer-" + String(Math.ceil(nextEndlessRuns / 3)));
      }
    }

    let newBadges = 0;
    for (const badgeId of newBadgeIds) {
      const result = db.prepare(
        "INSERT OR IGNORE INTO badges(player_id, badge_id, earned_at) VALUES (?, ?, ?)",
      ).run(player.id, badgeId, now);
      if (Number(result.changes) > 0) {
        newBadges += 1;
        const label = badgeLabels.get(badgeId) ||
          (badgeId.startsWith("explorer-") ? "Keşif Nişanı" : "Yeni Ustalık");
        addActivity(player.id, "badge", label);
      }
    }

    const badgeCount = Number(
      db.prepare("SELECT COUNT(*) AS count FROM badges WHERE player_id = ?").get(player.id).count,
    );
    db.prepare("UPDATE players SET badge_count = ? WHERE id = ?").run(badgeCount, player.id);

    if (kind === "endless") {
      addActivity(player.id, "endless", "");
    } else if (accuracy >= 0.7 && chapterId) {
      addActivity(player.id, "chapter", chapterLabels.get(chapterId));
    }

    db.exec("COMMIT");
    return {
      status: 200,
      payload: {
        points,
        stars,
        newBadges,
        weekKey: wk,
        repeatFactor,
        duplicate: false,
        durationAcceptedMs: durationMs,
      },
    };
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}

function handleSocial(token) {
  const player = playerByToken(token);
  if (!player) return { status: 401, payload: { error: "PLAYER_NOT_FOUND" } };
  const wk = weekKey();
  const weekly = rankRows(
    "SELECT p.id, p.public_name, p.avatar_id, p.badge_count, p.best_streak, w.score " +
      "FROM weekly_scores w JOIN players p ON p.id = w.player_id " +
      "WHERE w.week_key = ? ORDER BY w.score DESC, p.best_streak DESC, p.public_name COLLATE NOCASE ASC",
    [wk],
  );
  const overall = rankRows(
    "SELECT id, public_name, avatar_id, badge_count, best_streak, total_score AS score " +
      "FROM players ORDER BY total_score DESC, best_streak DESC, public_name COLLATE NOCASE ASC",
  );
  const badges = rankRows(
    "SELECT id, public_name, avatar_id, badge_count, best_streak, " +
      "badge_count * 100 + best_streak AS score FROM players " +
      "ORDER BY badge_count DESC, best_streak DESC, public_name COLLATE NOCASE ASC",
  );
  const streaks = rankRows(
    "SELECT id, public_name, avatar_id, badge_count, best_streak, best_streak AS score " +
      "FROM players WHERE best_streak > 0 " +
      "ORDER BY best_streak DESC, total_score DESC, public_name COLLATE NOCASE ASC",
  );
  const myIndex = weekly.findIndex((entry) => entry.id === player.id);
  const around =
    myIndex < 0
      ? []
      : weekly.slice(Math.max(0, myIndex - 2), Math.min(weekly.length, myIndex + 3));
  const totalCorrect = Number(
    db.prepare(
      "SELECT COALESCE(SUM(correct_count), 0) AS total FROM weekly_scores WHERE week_key = ?",
    ).get(wk).total,
  );
  const activity = db.prepare(
    "SELECT a.id, p.public_name AS name, p.avatar_id AS avatar, " +
      "a.event_type AS type, a.message, a.created_at AS createdAt " +
      "FROM activity a JOIN players p ON p.id = a.player_id ORDER BY a.id DESC LIMIT 12",
  ).all();
  return {
    status: 200,
    payload: {
      weekKey: wk,
      topWeekly: weekly.slice(0, 10),
      topOverall: overall.slice(0, 10),
      topBadges: badges.slice(0, 10),
      topStreaks: streaks.slice(0, 10),
      around,
      me: {
        id: player.id,
        weeklyRank: myIndex >= 0 ? myIndex + 1 : null,
        totalScore: Number(player.total_score || 0),
        badgeCount: Number(player.badge_count || 0),
        bestStreak: Number(player.best_streak || 0),
        endlessRuns: Number(player.endless_runs || 0),
      },
      classGoal: { current: totalCorrect, target: 500 },
      activity,
    },
  };
}

const mime = new Map([
  [".html", "text/html; charset=utf-8"],
  [".js", "text/javascript; charset=utf-8"],
  [".css", "text/css; charset=utf-8"],
  [".json", "application/json; charset=utf-8"],
  [".svg", "image/svg+xml"],
  [".jpg", "image/jpeg"],
  [".jpeg", "image/jpeg"],
  [".png", "image/png"],
  [".webp", "image/webp"],
  [".woff2", "font/woff2"],
  [".webmanifest", "application/manifest+json"],
]);

function serveStatic(req, res) {
  const dist = join(root, "dist");
  if (!existsSync(dist)) {
    sendJson(res, 404, { error: "BUILD_NOT_FOUND" });
    return;
  }
  const rawPath = decodeURIComponent(new URL(req.url, "http://localhost").pathname);
  const clean = rawPath === "/" ? "index.html" : rawPath.replace(/^\/+/, "");
  let candidate = resolve(join(dist, normalize(clean)));
  const relativeCandidate = relative(dist, candidate);
  if (
    relativeCandidate === ".." ||
    relativeCandidate.startsWith(".." + sep) ||
    relativeCandidate.includes(":" + sep)
  ) {
    res.writeHead(403);
    res.end();
    return;
  }
  if (!existsSync(candidate) || candidate.endsWith("\\")) candidate = join(dist, "index.html");
  try {
    const body = readFileSync(candidate);
    res.writeHead(200, {
      "content-type": mime.get(extname(candidate).toLowerCase()) || "application/octet-stream",
      "content-length": body.length,
      "x-content-type-options": "nosniff",
      "x-frame-options": "DENY",
      "referrer-policy": "no-referrer",
      "permissions-policy": "camera=(), microphone=(), geolocation=()",
      "content-security-policy":
        "default-src 'self'; img-src 'self' data:; font-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'",
    });
    res.end(req.method === "HEAD" ? undefined : body);
  } catch {
    res.writeHead(404);
    res.end();
  }
}

const server = createServer(async (req, res) => {
  try {
    const url = new URL(req.url, "http://localhost");
    if (url.pathname.startsWith("/api/") && limited(req)) {
      sendJson(res, 429, { error: "TOO_MANY_REQUESTS" });
      return;
    }
    if (url.pathname === "/api/health" && req.method === "GET") {
      sendJson(res, 200, { ok: true, weekKey: weekKey() });
      return;
    }
    if (url.pathname === "/api/players" && req.method === "POST") {
      const result = handleRegister(await readJson(req));
      sendJson(res, result.status, result.payload);
      return;
    }
    if (url.pathname === "/api/sessions" && req.method === "POST") {
      const result = handleSession(await readJson(req), req.headers["x-player-token"]);
      sendJson(res, result.status, result.payload);
      return;
    }
    if (url.pathname === "/api/social" && req.method === "GET") {
      const result = handleSocial(req.headers["x-player-token"]);
      sendJson(res, result.status, result.payload);
      return;
    }
    if (url.pathname.startsWith("/api/")) {
      sendJson(res, 404, { error: "NOT_FOUND" });
      return;
    }
    if (req.method === "GET" || req.method === "HEAD") {
      serveStatic(req, res);
      return;
    }
    res.writeHead(405);
    res.end();
  } catch (error) {
    const code =
      error?.message === "BODY_TOO_LARGE"
        ? 413
        : error?.message === "INVALID_JSON"
          ? 400
          : 500;
    sendJson(res, code, {
      error:
        code === 413
          ? "BODY_TOO_LARGE"
          : code === 400
            ? "INVALID_JSON"
            : "SERVER_ERROR",
    });
  }
});

server.listen(port, host, () => {
  console.log("Ritim Kaşifleri server: http://" + host + ":" + port);
  console.log("SQLite: " + dbPath);
});

function shutdown() {
  server.close(() => {
    db.close();
    process.exit(0);
  });
}

process.on("SIGINT", shutdown);
process.on("SIGTERM", shutdown);

